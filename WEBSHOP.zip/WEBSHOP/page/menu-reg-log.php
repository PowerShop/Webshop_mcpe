	<?php require 'head.php';?>
 
<header id="header">
				<a href="#" class="logo"><strong>MyServer</strong> Mcpe Thailand</a>
				<nav>
					<a href="#menu">เมนู</a>
				</nav>
			</header>

		<!-- Nav -->
			<nav id="menu">
				<ul class="links">
					<li><a href="?page=login">Login</a></li>
					<li><a href="?page=register">Register</a></li>
					
				</ul>
			
<center><code> &copy PowerShop MCPE</code></center>
</nav>