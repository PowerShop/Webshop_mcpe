<?php
if(!$_SESSION['email'])
{

    header("Location: ?page=login");//redirect to login page to secure the welcome page without login access.
}

?>
<?php
        include("login/database/db_conection.php");
		$email = $_SESSION['email'];
        $view_users_query="select * from truewallet where id = 1";//select query for viewing users.
        $run=mysqli_query($dbcon,$view_users_query);//here run the sql query.

		while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
		{
$truewallet_phone=$row[1];
	     $truewallet_username=$row[2];
            $truewallet_password=$row[3];
$host_name=$row[4];
$host_user=$row[5];
$host_pass=$row[6];
$host_db=$row[7];
    ?>
<head>
<meta name="viewport" content="width=device-width, initial-scale=2" />
    <meta charset="utf-8">
    <title>Payment With TrueWallet</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
	    <link rel="stylesheet" href="https://bulma.io/css/bulma-docs.css?v=201802201001">

<?php require 'menu.php';?>
    

<!--- script js --->
<script src="dist/js/jquery.min.js"></script>
			<script src="dist/js/jquery.scrolly.min.js"></script>
			<script src="dist/js/skel.min.js"></script>
			<script src="dist/js/util.js"></script>
			<script src="dist/js/main.js"></script>
    <meta charset="utf-8">
   
    
    <script src='https://www.google.com/recaptcha/api.js?hl=th'></script>
</head>

<script type="text/javascript">
    function autoTab(obj){
        var pattern=new String("___-___-____");
        var pattern_ex=new String("-");
        var returnText=new String("");
        var obj_l=obj.value.length;
        var obj_l2=obj_l-1;
        for(i=0;i<pattern.length;i++){
            if(obj_l2==i && pattern.charAt(i+1)==pattern_ex){
                returnText+=obj.value+pattern_ex;
                obj.value=returnText;
            }
        }
        if(obj_l>=pattern.length){
            obj.value=obj.value.substr(0,pattern.length);
        }
    }

</script>
<p>

<div class="panel panel-body">
    <div class="col-md-120">
        <div class="well well-sm" style="text-align: center">
            <br>
            <h2 style="font-size: 30px"><i class="far fa-money-bill-alt"></i>  เติมพอยท์ด้วย<font color="red"> True</font><font color="orange">Wallet</font></h2>
            <hr style="margin: 0; margin-top: 0px; margin-bottom: 20px;">
            <h3><h2 style="font-size: 18px"><legend>โอนเงินมาที่เบอร์ <?php echo $truewallet_phone;?><br>จะได้รับพอยท์ตามจำนวนเงิน</legend></h3>
			<hr>
           <form method="post">
		<script>
		function makeaction(){
			document.getElementById('btn_submit').disabled = false;  
			}
		</script>
                <div class="alert hidden"></div>
                <div class="form-group">
                    <h3><i class="fa fa-phone"></i> เบอร์โทรศัพท์</h3>
                    <input type="text" name="phone" onkeyup="autoTab(this)" maxlength="13" required="" class="form-control" placeholder="เบอร์โทรศัพท์ที่โอนมา">
                </div>
                <div class="form-group">
                    <h3><i class="fa fa-sort-numeric-down"></i> เลขอ้างอิง 10 - 14 หลัก</h3>
                    <input type="text" name="tw_id" maxlength="14" required="" class="form-control" placeholder="หมายเลขอ้างอิง">
 <input type="hidden" name="username" maxlength="200" required="" class="form-control" value="<?php echo $truewallet_username;?>">
 <input type="hidden" name="password" maxlength="200" required="" class="form-control" value="<?php echo $truewallet_password;?>">

                </div>
                <div class="form-group">
                    <button id="btn_submit" type="submit" class="btn btn-info" disabled><i class="fa fa-check"></i> เเจ้งโอน (ได้รับเงินทันที)</button>&nbsp <button id="btn_submit" type="reset" class="btn btn-danger"><i class="fa fa-times"></i> Reset</button>
					
                </div>
            </form>
			<center><div class="g-recaptcha" data-callback="makeaction" data-sitekey="6LeM5E0UAAAAAP8gvqSlLpV7hbpf92gOrXxxvPDC"></div></center>

        </div>
		</div>
		</div>
            </div>
</div>
</div>
</div>
</div>
<?php require 'footer.php';?>

<center>
        <?php
            if (isset($_POST['tw_id'])) {
            $t_id = $_POST['tw_id'];
            $t_phone = $_POST['phone'];
            
            //Show all error, remove it once you finished you code.
            ini_set('display_errors', 1);
            //Include TrueWallet class.
            include_once('manager/TrueWallet.php');
            $wallet = new TrueWallet();
            //Login with your username and password.
            $username = $_POST['username']; // ชื่อผู้ใช้ TW คุณ
            $password = $_POST['password']; // รหัสผ่าน TW คุณ
            //Logout incase your previous session still exist, no need if you only use 1 user.
            $wallet->logout();
            //Login into TrueWallet
            if ($wallet->login($username, $password)){
            //Get current profile.
            if ($profile = $wallet->get_profile()) {
                // echo "<pre>";
                // print_r($profile);
                // echo "</pre>";
            }
            //Show 50 lastest transaction.
            if ($transaction = $wallet->get_transactions()) {
                // echo "<pre>";
                // print_r($transaction);
                // echo "</pre>";
            }
            //Get full report of transaction.
            if ($transaction[0] && $report = $wallet->get_report($transaction[0]->reportID)) {
                // echo "<pre>";
                // print_r($report);
                // echo "</pre>";
            }
            //Examples
            //Get mobile number


            //$mobile_number = $profile->mobileNumber; // 081-234-5678
            //echo 'Mobile Number: '.$mobile_number.'<br>';


            $report_type_want = 'creditor';
            $report_type_phone = $t_phone;
            $last_report = 0;
            //(Later)Fetch your lastest report number here.
            //Get new transactions.
            foreach ($transaction as $tran) {
                //Get transaction type.
                $tran_type = $tran->text3En;
                //Get transaction report id.
                $tran_report = $tran->reportID;
                if ($tran_type == $report_type_want && $tran_report > $last_report) {
                    $tran_reportID = $tran->reportID; // 12345678
                    //Get full report.
                    $full_report = $wallet->get_report($tran_reportID);
                    //Get information from transaction.
                    $tran_amount = $full_report->amount; // 1234
                    $tran_from = $full_report->ref1; // 0812345678
                    $tran_message = $full_report->personalMessage->value; // message
                    $tran_date = $full_report->section4->column1->cell1->value; // 31/01/17 23:59
                    $tran_id = $full_report->section4->column2->cell1->value; // 1234567890
                    //(Later)Do stuff.


                }

            }


            //Get lastest 'creditor' transaction report id.
            foreach ($transaction as $tran) {
                $tran_type = $tran->text3En;
                $tran_type_phone = $tran->text5En;
                if ($tran_type_phone == $report_type_phone && $tran_type == $report_type_want) {

                    // Get lastest transaction report number of 'creditor'
                    // Note: Different transaction type may use different report id group.
                    //       ReportID is a unique id for your own account,
                    // 	  but transaction id is the same for both sender and reciver account.

                    $last_report = $tran->reportID;
                    $full_last_report = $wallet->get_report($last_report);
                    $last_trand_id = $full_last_report->section4->column2->cell1->value;
                    $last_tran_amount = $full_last_report->amount;

                    break;
                }
            }

            ?>

            <!-- Trigger/Open The Modal -->

            <!-- The Modal -->
            <div id="myModal" class="modal" style="margin: 5%">

                <!-- Modal content -->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" onclick="window.location='https://powershop.store/?page=topup'" class="close"
                                data-dismiss="modal">&times;
                        </button>
                    </div>
                    <div class="modal-body">
                        <div align="center">
<body>
<?php
                            if (isset($last_trand_id) && $last_trand_id != null) {
                                if (@$last_trand_id == $t_id) {
								
                                    $textA = $last_trand_id;
                                    $textB = $last_tran_amount;
                                    //Check MEMBERNo for dupplicate
                date_default_timezone_set('Asia/Bangkok');
                                    $conn = mysqli_connect('$host_name', '$host_user', '$host_pass', '$host_db');
                                    $id = $_SESSION['email'];
                                    $check = mysqli_query($conn, "SELECT * FROM `history`");
                                    $result = mysqli_query($conn, "SELECT * FROM `history` WHERE `tran_num`='$textA'");

                                    if ($result && $result->num_rows != 0) {
                                        echo "<img src='/page/img/Sign-Alert-icon.png' width='90' height='90'> <br> ";
                                        echo "ดำเนินการไม่สำเร็จ รหัสอ้างอิงถูกใช้ไปแล้ว!<br>";
                                    } else {
                                        echo "<img src='/page/img/success-icon.png' width='90' height='90'> <br> ";
                                        echo "แจ้งชำระเงินสำเร็จ<br>";
                                        echo "รหัสอ้างอิง : " . $last_trand_id . "<br>จำนวนเงิน : " . $last_tran_amount . " บาท<br>";
                                        //Insert to db
                                        $sqlll = mysqli_query($conn, "INSERT INTO `history`(`tran_num`,`amount`,`phone`,`DATETIME`) VALUES(" . $textA . "," . $textB ."," . $_POST["phone"] . ",'".trim(date("Y-m-d H:i:s"))."')");
                                        mysqli_query($conn, "INSERT INTO `tw_profile`(`fb_id`,`tran_number`,`amount`,`DATETIME`) VALUES('$id','". $textA ."','". $textB . "','".trim(date("Y-m-d H:i:s"))."')");
									    mysqli_query($conn, "UPDATE `user` SET point = point + " . $textB . " WHERE username = '$id'");

                                    }
                                } else {
									echo "<center>";
                                    echo "<img src='/page/img/Sign-Alert-icon.png' width='90' height='90'> <br> ";
                                    echo "ดำเนินการไม่สำเร็จ ไม่พบเลขอ้างอิงในระบบ!<br>";
									echo "</center>";
                                }
                            } else {
                                $textA = "<font color='red'>ผิดพลาด</font>";
                                $textB = "<font color='red'>ผิดพลาด</font>";
                                echo "<img src='/page/img/Sign-Alert-icon.png' width='90' height='90'> <br> ";
                                echo "ดำเนินการไม่สำเร็จ กรุณาลองอีกครั้ง!<br>";
                            }
                            }


                            //Logout
                            $wallet->logout();
                            }
                            ?>
</body>
  <script>
                // Get the modal
                var modal = document.getElementById('myModal');

                // Get the button that opens the modal

                var btn = document.getElementById("myBtn");

                // Get the <span> element that closes the modal
                var span = document.getElementsByClassName("close")[0];

                // When the user clicks the button, open the modal
                window.onload = function() {
                    modal.style.display = "block";
                }

                // When the user clicks on <span> (x), close the modal
                span.onclick = function() {
                    modal.style.display = "none";
                }

                // When the user clicks anywhere outside of the modal, close it
                window.onclick = function(event) {
                    if (event.target == modal) {
                        modal.style.display = "none";
                    }
                }
                $('#myModal').on('hidden.bs.modal', function(){
                    window.location='https://powershop.store/?page=wallet'
                });
            </script>
        </div>
    </div>
</div>
</center>
<?php } ?>