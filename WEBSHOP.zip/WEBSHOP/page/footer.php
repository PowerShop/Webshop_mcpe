<!--- Footer --->
<footer id="footer">
				<ul class="icons">
					<li><a href="#" class="icon fa-youtube"><span class="label">Twitter</span></a></li>
					<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
				</ul>
				
<div class="copyright">
					&copy; พัฒนาเว็บไซต์โดย : <a href="#">PowerShop MCPE</a>.
				
<div class="copyright"></div>
</div>
			
