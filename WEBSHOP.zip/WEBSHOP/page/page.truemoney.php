<?php


if(!$_SESSION['email'])
{

    header("Location: ?page=login");//redirect to login page to secure the welcome page without login access.
}

?>
 <?php
        include("login/database/db_conection.php");
		$email = $_SESSION['email'];
        $view_users_query="select * from truemoney where id = 1";//select query for viewing users.
        $run=mysqli_query($dbcon,$view_users_query);//here run the sql query.

		while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
		{
	     $truemoney_uid=$row[1];
            $truemoney_passkey=$row[2];
            
    
        ?>
<?php
        include("login/database/db_conection.php");
		$email = $_SESSION['email'];
        $view_users_query="select * from user where username = '$email'";//select query for viewing users.
        $run=mysqli_query($dbcon,$view_users_query);//here run the sql query.

		while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
		{
	     $uid=$row[0];
            $username=$row[1];
            
    
        ?>
<head>
    <meta charset="utf-8">
    <title>Payment</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
	    <link rel="stylesheet" href="https://bulma.io/css/bulma-docs.css?v=201802201001">
<!--- script js --->
<script src="dist/js/jquery.min.js"></script>
			<script src="dist/js/jquery.scrolly.min.js"></script>
			<script src="dist/js/skel.min.js"></script>
			<script src="dist/js/util.js"></script>
			<script src="dist/js/main.js"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>

    <meta charset="utf-8">
    <?php require 'menu.php';?>
    <?php require 'header.php';?>
    <script src='https://www.google.com/recaptcha/api.js?hl=th'></script>
</head>
<br>
<br>
<br>
<p>
<div class="container">
<div clasa="panel panel-body">
    <div class="col-md-120">
  <div class="well well-sm" style="text-align: center">
<h2 style="font-size: 30px"><i class="far fa-money-bill-alt"></i> เติมพอยท์ด้วย <font color="red">True</font><font color="orange">Money</font></h2>
<br>
<head>
<div class="form-group">
 <script type="text/javascript" src="https://www.tmtopup.com/topup/3rdTopup.php?uid=<?php echo $truemoney_uid;?>"></script>
            <div class="form-group">
<div class="input-group">
  <span class="input-group-addon"><i class="fas fa-user-circle"></i> Username :&nbsp</span> <input type="text" class="form-control" disabled id="ref1" value="<?php echo $username;?>">
</div>
</div>
            
     <div class="form-group">
<div class="input-group">
   <span class="input-group-addon"><i class="far fa-money-bill-alt"></i> TrueMoney :  &nbsp</span> <input type="text" name="tmn_password" id="tmn_password" class="form-control" min="14" maxlength="14" placeholder="รหัสบัตรทรูมันนี่">
            </div>
</div>
 <div class="form-group">
                <input  class="form-control" type="hidden" id="ref2" value="<?php echo $username;?>" maxlength="50">
            </div>
           
            <div class="form-group">
                <input class="form-control" type="hidden" id="ref3" value="Thx" maxlength="50">
            </div>
            <button class="btn btn-success" onclick="submit_tmnc()"><i class="fas fa-check-circle"></i> ดำเนินการเติมพอยท์</button>
            <br>
            <br>
        </div>
    </div>
</div>
</div>
</div>
</div>
</div>
</div>
<hr style="margin-left: 35px; margin-right: 35px">
                 <?php require 'footer.php';?>
<?php } ?>
<?php } ?>