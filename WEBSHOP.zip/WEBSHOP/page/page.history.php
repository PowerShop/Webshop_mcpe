
<?php
if(!$_SESSION['email'])
{

    header("Location: ?page=login");//redirect to login page to secure the welcome page without login access.
}
?>
<head>

	<title>ประวัติการเติมพอยท์</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
	  
</head>
<?php require 'menu.php';?>
<?php require 'head.php;?>
<p>
<div class="col-md-120">
 <div class="panel panel-default">
    <div class="panel-body">
      <legend><i class="fas fa-money-bill-alt" aria-hidden="true"></i> 5 อันดับการเติมเงิน</legend>
      <table class="table table-striped table-hover ">
  <thead>
    <tr>
      <th>#</th>
      <th><i class="fas fa-users"></i> ชื่อตัวละคร</th>
      <th><i class="fas fa-money-bill-alt"></i> จำนวนเงิน</th>
    </tr>
  </thead>
  <tbody>
    <?php 
    $query = "SELECT * FROM `user` ORDER BY `point` DESC LIMIT 5;"; 
    if($result = query($query)) { 
    while ($row = $result->fetch()){ 
      ?>
    <tr class="active">
      <td><img  class="img" src="https://minotar.net/avatar/clone1018/100.png<?php echo $row['user'];?>" height="25"></td>
      <td><?php echo $row['username'];?></td>
      <td><?php echo $row['point']; ?> Point</td>
      </tr><?php }}?>
      </tbody>
</table>
    </div>
  </div>

