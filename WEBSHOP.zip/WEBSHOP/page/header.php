<link rel="stylesheet" href="dist/css/font-awesome.min.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.0/css/bulma.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.0/css/bulma.css.map" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.0/css/bulma.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.4.0/css/bulma.min.css.map" rel="stylesheet">
<link rel="stylesheet" href="dist/css/bulma.css.map">
<script src="https://code.jquery.com/jquery-3.0.0.js"></script>

<link href="https://fonts.googleapis.com/css?family=Mitr" rel="stylesheet">
    <style>
      body {
		font-family: 'Mitr', cursive;
                font-size: 12px;
      }
       
      h3 {
                font-family: 'Mitr', cursive;
                font-size: 20px;
      }

  h1 {
                font-family: 'Mitr', cursive;
                font-size: 30px;
      }

  h2 {
                font-family: 'Mitr', cursive;
                font-size: 20px;
      }
    </style>
    <link href="https://fonts.googleapis.com/css?family=Mitr" rel="stylesheet">
    <style>
      .font-mitr {
		font-family: 'Mitr', cursive;
                font-size: 15px;
      }
    </style>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  
      
