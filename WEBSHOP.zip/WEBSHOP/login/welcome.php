<?php
session_start();

if(!$_SESSION['email'])
{

    header("Location: /login");//redirect to login page to secure the welcome page without login access.
}

?>

<html>
<head>

    <title>
        Registration
    </title>
</head>

<body>
<h1>Welcome</h1><br>
        <?php
        include("database/db_conection.php");
		$email = $_SESSION['email'];
        $view_users_query="select * from users where user_email = '$email'";//select query for viewing users.
        $run=mysqli_query($dbcon,$view_users_query);//here run the sql query.

		while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
		{
	     $user_id=$row[0];
            $user_name=$row[1];
            $user_email=$row[2];
            $user_pass=$row[3];
			
        ?>
<?php
//การดึงข้อมูล
echo $user_name; //ทำการดึง Username โดยใช้ email เป็นตัวเเปร
//ดึงข้อมูลเสร็จสิ้น
?>

<h1><a href="logout.php">Logout here</a> </h1>


</body>

</html>

</html>
<?php } ?>