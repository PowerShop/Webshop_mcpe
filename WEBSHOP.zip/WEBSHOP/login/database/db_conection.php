<?php
/*
 * ไม่เข้าใจ ติดต่อเพจ PowerShop MCPE
 */

$dbcon=mysqli_connect("localhost","root","");

// localhost คือ host ของท่าน
// root คือ username phpmyadmin 
// "" ช่องที่เว้นว่างไว้คือ Password ของ phpmyadmin
// powersho_demo คือ ชื่อฐานข้อมูล ไม่ต้องเเก้!
mysqli_select_db($dbcon,"powersho_demo");

?>