<?php
/**
 * Created by PhpStorm.
 * User: Ehtesham Mehmood
 * Date: 24/03/2018
 * Time: 7:35AM
 */

session_start();//session is a way to store information (in variables) to be used across multiple pages.
session_destroy();
header("Location: /login");//use for the redirection to some page
?>