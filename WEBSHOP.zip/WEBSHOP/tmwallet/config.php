<?php
# ------------------------------------- Config Begin ------------------------------------- #
// ------------------------------------------------------------------------------------------------
/* หากลูกค้าไม่เข้าใจ ทางเพจ PowerShop MCPE รับ Setup ให้ฟรี */
/* MySQL Config | Begin */
// Hostname ของ MySQL Server
$_CONFIG['mysql']['dbhost'] = '127.0.0.1'; // Host phpmyadmin 

// Username ที่ใช้เชื่อมต่อ MySQL Server
$_CONFIG['mysql']['dbuser'] = 'root'; // User phpmyadmin 

// Password ที่ใช้เชื่อมต่อ MySQL Server
$_CONFIG['mysql']['dbpw'] = ''; // Password phpmyadmin 

// ชื่อฐานข้อมูลที่เราจะเติม Point ให้
$_CONFIG['mysql']['dbname'] = 'webshop'; // Database phpmyadmin 

// ชื่อตารางที่เราจะเติม Point ให้ ตัวอย่าง : member
$_CONFIG['mysql']['tbname'] = 'user'; // Table phpmyadmin 

// ชื่อ field ที่ใช้อ้าง Username
$_CONFIG['mysql']['field_username'] = 'username'; // Field อ้างอิง Username

// ชื่อ field ที่ใช้ในการเก็บ Point จากการเติมเงิน
$_CONFIG['TMN']['point_field_name'] = 'point'; // Field เก็บ Point 
/* MySQL Config | End */
// ------------------------------------------------------------------------------------------------


// ------------------------------------------------------------------------------------------------
/* จำนวน Point ที่จะได้รับเมื่อเติมเงินในราคาต่างๆ | Begin */
$_CONFIG['TMN'][50]['point'] = 50;					// Point ที่ได้รับเมื่อเติมเงินราคา 50 บาท
$_CONFIG['TMN'][90]['point'] = 90;					// Point ที่ได้รับเมื่อเติมเงินราคา 90 บาท
$_CONFIG['TMN'][150]['point'] = 150;				// Point ที่ได้รับเมื่อเติมเงินราคา 150 บาท
$_CONFIG['TMN'][300]['point'] = 300;				// Point ที่ได้รับเมื่อเติมเงินราคา 300 บาท
$_CONFIG['TMN'][500]['point'] = 500;				// Point ที่ได้รับเมื่อเติมเงินราคา 500 บาท
$_CONFIG['TMN'][1000]['point'] = 1000;			// Point ที่ได้รับเมื่อเติมเงินราคา 1,000 บาท
/* จำนวน Point ที่จะได้รับเมื่อเติมเงินในราคาต่างๆ | End */
// ------------------------------------------------------------------------------------------------


define('API_PASSKEY', '####'); // กำหนด Passkey อะก็ได้
