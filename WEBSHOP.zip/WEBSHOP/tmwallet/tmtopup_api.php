<?php
require 'config.php';
/* API Connection  TMTopup for Dadteam.Com*/
/*
* Modify by Nst Interactive [http://www.nstinteractive.com/]
*/



// กำหนด API Passkey


# -------------------------------------- Config End -------------------------------------- #


require_once('AES.php');


// ------------------------------------------------------------------------------------------------
/* เชื่อมต่อฐานข้อมูล | Begin */
mysql_connect($_CONFIG['mysql']['dbhost'],$_CONFIG['mysql']['dbuser'],$_CONFIG['mysql']['dbpw']) or die('ERROR|DB_CONN_ERROR|' . mysql_error());
mysql_select_db($_CONFIG['mysql']['dbname']) or die('ERROR|DB_SEL_ERROR|' . mysql_error());
/* เชื่อมต่อฐานข้อมูล | End */
// ------------------------------------------------------------------------------------------------


if($_SERVER['REMOTE_ADDR'] == '203.146.127.115' && isset($_GET['request']))
{
	$aes = new Crypt_AES();
	$aes->setKey(API_PASSKEY);
	$_GET['request'] = base64_decode(strtr($_GET['request'], '-_,', '+/='));
	$_GET['request'] = $aes->decrypt($_GET['request']);
	if($_GET['request'] != false)
	{
		parse_str($_GET['request'],$request);
		$request['Ref1'] = base64_decode($request['Ref1']);

		/* Database connection | Begin */
		$result = mysql_query('SELECT * FROM `'. $_CONFIG['mysql']['tbname'] .'` WHERE `'. $_CONFIG['mysql']['field_username'] .'`=\'' . mysql_real_escape_string($request['Ref1']) . '\' LIMIT 1') or die(mysql_error());
		if(mysql_num_rows($result) == 1)
		{
			$row = mysql_fetch_assoc($result);
			if(mysql_query("UPDATE `". $_CONFIG['mysql']['tbname'] ."` SET `". $_CONFIG['TMN']['point_field_name'] ."` = `". $_CONFIG['TMN']['point_field_name'] ."`+'". $_CONFIG['TMN'][$request['cardcard_amount']]['point'] ."' WHERE `". $_CONFIG['mysql']['field_username'] ."` = '". $row[$_CONFIG['mysql']['field_username']] ."' LIMIT 1 ") == false)
			{
				echo 'ERROR|MYSQL_UDT_ERROR|' . mysql_error();
			}
			else
			{
			//	mail($request['Ref3'], 'ขอบพระคุณที่เลือกใช้บริการของเรา', 'ท่านได้ทำการเติมเงินด้วยบัตรเงินสดทรูมันนี่จำนวน ' . $request['cashcard_amount'] . ' บาท ขอบพระคุณที่ท่านเลือกใช้บริการของเรา');
				echo 'SUCCEED|UID=' . $row[$_CONFIG['mysql']['field_username']];
			}
		}
		else
		{
			if(mysql_query("INSERT INTO `". $_CONFIG['mysql']['tbname'] ."`  (`". $_CONFIG['mysql']['field_username'] ."` , `". $_CONFIG['TMN']['point_field_name'] ."`) VALUES ('". $request['Ref1'] ."', 0)") == false)
			{
				echo 'ERROR|MYSQL_UDT_ERROR|' . mysql_error();
			}
			else
			{
				$result = mysql_query('SELECT * FROM `'. $_CONFIG['mysql']['tbname'] .'` WHERE `'. $_CONFIG['mysql']['field_username'] .'`=\'' . mysql_real_escape_string($request['Ref1']) . '\' LIMIT 1') or die(mysql_error());
				if(mysql_num_rows($result) == 1)
				{
					$row = mysql_fetch_assoc($result);
					if(mysql_query("UPDATE `". $_CONFIG['mysql']['tbname'] ."` SET `". $_CONFIG['TMN']['point_field_name'] ."` = `". $_CONFIG['TMN']['point_field_name'] ."`+'". $_CONFIG['TMN'][$request['cardcard_amount']]['point'] ."' WHERE `". $_CONFIG['mysql']['field_username'] ."` = '". $row[$_CONFIG['mysql']['field_username']] ."' LIMIT 1 ") == false)
					{
						echo 'ERROR|MYSQL_UDT_ERROR|' . mysql_error();
					}
					else
					{
					//	mail($request['Ref3'], 'ขอบพระคุณที่เลือกใช้บริการของเรา', 'ท่านได้ทำการเติมเงินด้วยบัตรเงินสดทรูมันนี่จำนวน ' . $request['cashcard_amount'] . ' บาท ขอบพระคุณที่ท่านเลือกใช้บริการของเรา');
						echo '[2]SUCCEED|UID=' . $row[$_CONFIG['mysql']['field_username']];
					}
				} 
				else 
				{
					echo 'ERROR|INCORRECT_USERNAME';
				}	
			}
		//	echo 'ERROR|INCORRECT_USERNAME';
		}
		/* Database connection | End */

	}
	else
	{
		echo 'ERROR|INVALID_PASSKEY';
	}
}
else
{
	echo 'ERROR|ACCESS_DENIED';
}
?>