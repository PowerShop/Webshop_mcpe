<?php
/*
ไฟล์การตั้งค่า Rcon ขออภัยที่ไม่มีการตั้งค่าใน Backend 
*/

$serverName = "###"; /* ชื่อที่เเสดงบริเวณ ด้านบนของ Console */

$rconHost = "###"; /* IP ของ Server */
$rconPort = ###; /* Port ของ Server */
$rconPassword = "###"; /* Password Rcon ของท่าน */

$queryHost = "127.0.0.1"; /* ไม่ต้องเเก้ */
$queryPort = 19132; /* ไม่ต้องเเก้ */